# Reto 10 - 2025 🚀

## **Historia**
Softparty tiene un sistema web para registrar usuarios en el evento.  
Este sistema permite que las personas ingresen su **nombre**, **apellido** y **correo electrónico**, y que esos datos aparezcan en una tabla de usuarios registrados.

Pero… **¡el sistema ha fallado justo antes del evento!** 😱  
El formulario no funciona como debería:

- ❌ No muestra la alerta de confirmación.
- ❌ No agrega los datos a la tabla.
- ❌ Y hay algunos errores misteriosos en el código.

---

## **Tu misión**
Como desarrollador/a, debes **revisar el código**, encontrar los errores y corregirlos para que el sistema vuelva a funcionar.

---

## **Objetivo del sistema**
Al llenar el formulario y presionar **Enviar**:

1. ✅ Debe aparecer una **alerta bonita** que confirme el registro (usando SweetAlert2).
2. ✅ Los datos ingresados deben **agregarse a la tabla** de usuarios registrados.
3. ✅ El formulario debe **limpiarse** después de cada registro.

---

## **Requisitos del reto**
- 🔍 Revisar el código fuente que está en el repositorio de GitHub.
- 🛠 Usar el **inspector del navegador (DevTools)** para encontrar errores en consola y en el DOM.
- 🔧 Corregir los errores **sin reescribir todo el proyecto**:
  - Mantén la estructura **HTML y CSS**.
  - No elimines funcionalidades, solo arréglalas.
- ⚠️ La alerta debe ser con **SweetAlert2** (no vale `alert()`).
- 💻 El sistema debe funcionar en **navegador de escritorio**.

---

¡Éxitos y que comience el reto! 💪